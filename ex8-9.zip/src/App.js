import './App.css';
import Navigation from './component/Navigation';
//import Player from './component/Players';
import Footer from './component/Footer';
import Main from './component/Main';

function App() {
  return (
    <div className="App">
      <Navigation/>
      <Main/>
      <Footer/>
    </div>
  );
}

export default App;
