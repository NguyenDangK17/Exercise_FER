import React, {Component} from 'react'
export default class Footer extends Component{
    render(){
        return(
            <span>
                <footer>copyright © 2022</footer>
            </span>
        )
    }
}