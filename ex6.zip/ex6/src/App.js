import './App.css';
import Navigation from './component/Navigation';
import Player from './component/Players';
import Footer from './component/Footer';

function App() {
  return (
    <div className="App">
      <Navigation/>
      <Player/>
      <Footer/>
    </div>
  );
}

export default App;
